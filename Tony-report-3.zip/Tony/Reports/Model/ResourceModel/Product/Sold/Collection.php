<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Report Sold Products collection
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
namespace Tony\Reports\Model\ResourceModel\Product\Sold;

/**
 * @SuppressWarnings(PHPMD.DepthOfInheritance)
 */
class Collection extends \Magento\Reports\Model\ResourceModel\Order\Collection
{
    /**
     * Set Date range to collection
     *
     * @param int $from
     * @param int $to
     * @return $this
     */
    public function setDateRange($from, $to)
    {
        $this->_reset()->addAttributeToSelect(
            '*'
        )->addOrderedQty(
            $from,
            $to
        );
        return $this;
    }

    /**
     * Add ordered qty's
     *
     * @param string $from
     * @param string $to
     * @return $this
     */
    public function addOrderedQty($from = '', $to = '')
    {
        $connection = $this->getConnection();
        $orderTableAliasName = $connection->quoteIdentifier('order');
        //$countCollection = Mage::getResourceModel('catalog/product_collection');

        $_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $compositeTypeIds = $_objectManager->get('Magento\Catalog\Model\Product\Type')->getCompositeTypes();
        $productTypes = $this->getConnection()->quoteInto(' AND (e.type_id NOT IN (?))', $compositeTypeIds);

        $orderJoinCondition = [
            $orderTableAliasName . '.entity_id = order_items.order_id',
            $connection->quoteInto("{$orderTableAliasName}.state <> ?", \Magento\Sales\Model\Order::STATE_CANCELED),
        ];
        
        

        if ($from != '' && $to != '') {
            $fieldName = $orderTableAliasName . '.created_at';
            $orderJoinCondition[] = $this->prepareBetweenSql($fieldName, $from, $to);
        }

        $this->getSelect()->reset()->from(
            ['order_items' => $this->getTable('sales_order_item')],
           
          
            ['order_date' => 'order.created_at','order_number' => 'order.increment_id' ,'order_shipping_date'=>'DATE(qa.created_at)', 'order_delivery_date'=>'DATE(soh.created_at)','order_delivery_days'=>'DATEDIFF(soh.created_at, qa.created_at)', 'order_delivery_city' => 'soa.city', 'order_delivery_region' => 'soa.region']
            
        )->joinInner(
            ['order' => $this->getTable('sales_order')],
            implode(' AND ', $orderJoinCondition),
            'customer_id'
        )
        ->joinLeft(array('soa' => 'sales_order_address'),"order.entity_id=soa.parent_id AND soa.address_type='shipping'")
        ->joinLeft(array('qa' => 'quote_address'),"order.quote_id=qa.quote_id AND qa.address_type='shipping'")
        ->joinLeft(array('soh' => 'sales_order_status_history'),"order.entity_id=soh.parent_id AND soh.status IN ('delivered','complete') AND soh.entity_name='order'")
         ->where(
            "order.status IN ('complete', 'delivered')"
        )->group(
            'order.increment_id'
        )->order('order_items.name');
        return $this;
    }
    
    
  
    /**
     * Set store filter to collection
     *
     * @param array $storeIds
     * @return $this
     */
    public function setStoreIds($storeIds)
    {
        if ($storeIds) {
            $this->getSelect()->where('order_items.store_id IN (?)', (array)$storeIds);
        }
        return $this;
    }

    /**
     * Set order
     *
     * @param string $attribute
     * @param string $dir
     * @return $this
     */
    public function setOrder($attribute, $dir = self::SORT_ORDER_DESC)
    {
        if (in_array($attribute, ['orders', 'ordered_qty'])) {
            $this->getSelect()->order($attribute . ' ' . $dir);
        } else {
            parent::setOrder($attribute, $dir);
        }

        return $this;
    }

    /**
     * Prepare between sql
     *
     * @param string $fieldName Field name with table suffix ('created_at' or 'main_table.created_at')
     * @param string $from
     * @param string $to
     * @return string Formatted sql string
     */
    protected function prepareBetweenSql($fieldName, $from, $to)
    {
        return sprintf(
            '(%s BETWEEN %s AND %s)',
            $fieldName,
            $this->getConnection()->quote($from),
            $this->getConnection()->quote($to)
        );
    }
}
